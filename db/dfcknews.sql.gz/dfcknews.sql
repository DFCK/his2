# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.6.14)
# Database: dfck_mis
# Generation Time: 2014-10-08 11:01:42 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table dfck_news
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dfck_news`;

CREATE TABLE `dfck_news` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `place` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `shortinfo` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `created_time` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(12) DEFAULT NULL,
  `hospital_code` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `view` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `dfck_news` WRITE;
/*!40000 ALTER TABLE `dfck_news` DISABLE KEYS */;

INSERT INTO `dfck_news` (`id`, `place`, `title`, `shortinfo`, `content`, `created_time`, `updated_at`, `created_at`, `deleted_at`, `created_by`, `hospital_code`, `view`)
VALUES
	(1,'99','Thông báo 1','tóm tắt thông báo 1','Nội dung thông báo 1',1412765976,'2014-10-08 17:59:36','2014-10-08 17:59:36',NULL,803140000001,'71111',NULL),
	(2,'kkb','Bản tin khoa KB 1','tóm tắt bản tin khoa khám bệnh 1','nội dung bản tin\n                                ',1412766004,'2014-10-08 18:00:04','2014-10-08 18:00:04',NULL,803140000002,'71111',NULL);

/*!40000 ALTER TABLE `dfck_news` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
