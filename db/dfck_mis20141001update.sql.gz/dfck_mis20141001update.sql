# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.6.14)
# Database: dfck_mis
# Generation Time: 2014-10-01 11:02:52 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table dfck_employee
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dfck_employee`;

CREATE TABLE `dfck_employee` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hospital_code` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `pid` bigint(12) DEFAULT NULL,
  `title` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `dfck_employee` WRITE;
/*!40000 ALTER TABLE `dfck_employee` DISABLE KEYS */;

INSERT INTO `dfck_employee` (`id`, `hospital_code`, `pid`, `title`, `updated_at`, `created_at`, `deleted_at`, `created_by`)
VALUES
	(1,'74001',711140000040,'bsi','2014-10-01 11:40:14','2014-09-30 21:13:20',NULL,NULL),
	(2,'74001',711140000044,'ddg','2014-10-01 11:39:54','2014-09-30 21:18:49',NULL,NULL),
	(3,'74001',711140000045,'ddg','2014-09-30 23:44:55','2014-09-30 21:20:23',NULL,NULL);

/*!40000 ALTER TABLE `dfck_employee` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table dfck_employee_position
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dfck_employee_position`;

CREATE TABLE `dfck_employee_position` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `dfck_employee_position` WRITE;
/*!40000 ALTER TABLE `dfck_employee_position` DISABLE KEYS */;

INSERT INTO `dfck_employee_position` (`id`, `name`, `code`, `lang`, `updated_at`, `created_at`, `deleted_at`)
VALUES
	(2,'Trưởng Phòng','truongphong','truongphong','2014-08-02 21:44:20','2014-08-02 21:44:20',NULL),
	(3,'Giám đốc','giamdoc','giamdoc','2014-08-02 22:03:15','2014-08-02 22:03:15',NULL);

/*!40000 ALTER TABLE `dfck_employee_position` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table dfck_employee_position_role
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dfck_employee_position_role`;

CREATE TABLE `dfck_employee_position_role` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `function_code` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `position_code` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `role` tinyint(1) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `dfck_employee_position_role` WRITE;
/*!40000 ALTER TABLE `dfck_employee_position_role` DISABLE KEYS */;

INSERT INTO `dfck_employee_position_role` (`id`, `function_code`, `position_code`, `role`, `updated_at`, `created_at`)
VALUES
	(1,'pasdk','truongphong',1,'2014-08-02 23:44:25','2014-08-02 22:01:34'),
	(2,'pas2','truongphong',1,'2014-08-02 23:44:28','2014-08-02 22:02:26'),
	(3,'paskb','truongphong',1,'2014-08-02 22:02:56','2014-08-02 22:02:56'),
	(4,'riscls','truongphong',3,'2014-08-02 22:02:57','2014-08-02 22:02:57'),
	(5,'pasadmit','truongphong',3,'2014-08-02 22:02:59','2014-08-02 22:02:59'),
	(6,'pasdk','giamdoc',3,'2014-08-02 22:03:26','2014-08-02 22:03:26'),
	(7,'pas2','giamdoc',3,'2014-08-02 22:03:27','2014-08-02 22:03:27'),
	(8,'pasadmit','giamdoc',3,'2014-08-02 22:03:28','2014-08-02 22:03:28'),
	(9,'paskb','giamdoc',3,'2014-08-02 22:03:28','2014-08-02 22:03:28'),
	(10,'riscls','giamdoc',3,'2014-08-02 22:03:29','2014-08-02 22:03:29');

/*!40000 ALTER TABLE `dfck_employee_position_role` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table dfck_employee_title
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dfck_employee_title`;

CREATE TABLE `dfck_employee_title` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `lang` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `group` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `dfck_employee_title` WRITE;
/*!40000 ALTER TABLE `dfck_employee_title` DISABLE KEYS */;

INSERT INTO `dfck_employee_title` (`id`, `created_at`, `updated_at`, `deleted_at`, `name`, `code`, `lang`, `group`)
VALUES
	(4,'2014-08-02 01:12:02','2014-08-02 01:12:02','0000-00-00 00:00:00','Điều dưỡng','ddg','ddg','gdd'),
	(8,'2014-08-02 01:20:59','2014-08-02 01:20:59','0000-00-00 00:00:00','Bác Sĩ','bsi','bsi','gbs');

/*!40000 ALTER TABLE `dfck_employee_title` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table dfck_employee_title_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dfck_employee_title_group`;

CREATE TABLE `dfck_employee_title_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `lang` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `dfck_employee_title_group` WRITE;
/*!40000 ALTER TABLE `dfck_employee_title_group` DISABLE KEYS */;

INSERT INTO `dfck_employee_title_group` (`id`, `created_at`, `updated_at`, `deleted_at`, `name`, `code`, `lang`)
VALUES
	(1,'2014-07-23 22:33:38','0000-00-00 00:00:00','0000-00-00 00:00:00','Bác Sĩ','gbs','gbs.lang'),
	(2,'2014-07-23 22:34:13','0000-00-00 00:00:00','0000-00-00 00:00:00','Y tá, Điều dưỡng','gdd','gdd.lang');

/*!40000 ALTER TABLE `dfck_employee_title_group` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table dfck_employee_transfer
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dfck_employee_transfer`;

CREATE TABLE `dfck_employee_transfer` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hospital_code` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `dept_code` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `ward_code` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `room_code` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `pid` bigint(20) DEFAULT NULL,
  `empid` int(11) DEFAULT NULL,
  `position_code` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `titlegroup` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `dfck_employee_transfer` WRITE;
/*!40000 ALTER TABLE `dfck_employee_transfer` DISABLE KEYS */;

INSERT INTO `dfck_employee_transfer` (`id`, `hospital_code`, `dept_code`, `ward_code`, `room_code`, `pid`, `empid`, `position_code`, `title`, `titlegroup`, `updated_at`, `created_at`, `deleted_at`)
VALUES
	(1,'74001','kkb','khukb','kkbpk2',711140000040,1,'truongphong','bsi','gbs','2014-10-01 16:24:40','2014-10-01 14:54:51',NULL),
	(2,'74001','khngoai','knpt','0',711140000040,1,'giamdoc','bsi','gbs','2014-10-01 16:24:02','2014-10-01 16:24:02',NULL),
	(3,'74001','hscc','0','0',711140000044,2,'truongphong','ddg','gdd','2014-10-01 17:40:06','2014-10-01 17:40:06',NULL),
	(4,'74001','khngoai','knpt','0',711140000045,3,'truongphong','ddg','gdd','2014-10-01 17:41:30','2014-10-01 17:41:30',NULL);

/*!40000 ALTER TABLE `dfck_employee_transfer` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table dfck_function
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dfck_function`;

CREATE TABLE `dfck_function` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted` int(11) DEFAULT '0',
  `order` int(11) DEFAULT NULL,
  `icon` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `modulecode` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `dfck_function` WRITE;
/*!40000 ALTER TABLE `dfck_function` DISABLE KEYS */;

INSERT INTO `dfck_function` (`id`, `name`, `url`, `lang`, `code`, `parent`, `updated_at`, `created_at`, `deleted`, `order`, `icon`)
VALUES
	(1,'Phòng Khám','','pas.phongkham','pas2',0,'2014-09-30 23:46:50','2014-07-17 14:37:44',0,1,'fa fa-lg fa-fw fa-user-md'),
	(9,'Chẩn đoán hình ảnh','','ris.cdha','riscdha',0,'2014-09-30 23:46:50','2014-07-17 15:01:05',0,2,'fa fa-lg fa-fw fa-codepen'),
	(12,'Tiếp nhận','/radt/tiepnhan','pas.admit','pasadmit',1,'2014-09-30 23:46:50','2014-07-17 15:03:36',0,0,NULL),
	(13,'Khám bệnh','/radt/khambenh','pas.kb','paskb',1,'2014-09-30 23:46:50','2014-07-17 15:05:01',0,1,''),
	(15,'Đăng ký mới','/pas/person','pas.dk','pasdk',0,'2014-09-30 23:46:50','2014-07-17 15:10:58',0,0,'fa fa-lg fa-fw fa-barcode'),
	(16,'Siêu âm','/ris/sieuam','ris.sieuam','rissieuam',9,'2014-09-30 23:46:50','2014-08-07 23:53:49',0,0,''),
	(17,'X-Quang','/ris/xquang','ris.xquang','risxquang',9,'2014-09-30 23:46:50','2014-08-08 12:05:38',0,1,''),
	(21,'CT Scanner','ris/ct','ris.ct','risct',9,'2014-09-30 23:46:50','2014-08-16 13:22:19',0,3,NULL),
	(22,'Nội soi','ris/noisoi','ris.noisoi','risnoisoi',9,'2014-09-30 23:46:50','2014-08-16 13:22:47',0,2,NULL),
	(23,'MRI','ris/mri','ris.mri','rismri',9,'2014-09-30 23:46:50','2014-08-16 13:23:09',0,4,NULL),
	(24,'Quản lý nhân sự','','hrm.hrm','hrm',0,'2014-09-30 23:46:50','2014-09-30 23:45:45',0,3,'fa fa-lg fa-fw fa-group'),
	(25,'Quản lý nhân viên','/hrm/employee','hrm.adminemployee','adminemployee',24,'2014-10-01 14:18:38','2014-09-30 23:46:36',0,0,NULL),
	(26,'Phân bổ nhân viên','/hrm/transfer','hrm.transfer','hrmtransfer',24,'2014-10-01 14:18:46','2014-09-30 23:48:50',0,0,''),
	(27,'Tài khoản & Phân Quyền','/hrm/role','hrm.accountnrole','hrmrole',24,'2014-10-01 17:53:53','2014-10-01 17:52:58',0,0,'');

/*!40000 ALTER TABLE `dfck_function` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
