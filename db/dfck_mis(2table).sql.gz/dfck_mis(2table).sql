-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2014 at 08:23 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dfck_mis`
--

-- --------------------------------------------------------

--
-- Table structure for table `dfck_employee_title`
--

CREATE TABLE IF NOT EXISTS `dfck_employee_title` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `lang` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `group` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `dfck_employee_title`
--

INSERT INTO `dfck_employee_title` (`id`, `created_at`, `updated_at`, `deleted_at`, `name`, `code`, `lang`, `group`) VALUES
(4, '2014-08-01 18:12:02', '2014-08-01 18:12:02', '0000-00-00 00:00:00', 'Điều dưỡng', 'ddg', 'ddg', 'gdd'),
(8, '2014-08-01 18:20:59', '2014-08-01 18:20:59', '0000-00-00 00:00:00', 'Bác Sĩ', 'bsi', 'bsi', 'gbs');

-- --------------------------------------------------------

--
-- Table structure for table `dfck_employee_title_group`
--

CREATE TABLE IF NOT EXISTS `dfck_employee_title_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `lang` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `dfck_employee_title_group`
--

INSERT INTO `dfck_employee_title_group` (`id`, `created_at`, `updated_at`, `deleted_at`, `name`, `code`, `lang`) VALUES
(1, '2014-07-23 15:33:38', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Bác Sĩ', 'gbs', 'gbs.lang'),
(2, '2014-07-23 15:34:13', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Y tá, Điều dưỡng', 'gdd', 'gdd.lang');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
